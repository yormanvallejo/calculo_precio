
// All functionality has been moved to index.html to support local "double-click" usage
// and prevent the "Failed to resolve module specifier" error in the browser environment.
